function callbackLogin(){
    //alert("登录状态");
    $("#payApplyForm").submit();
}

function callbackLogout(){
    alert("登录超时， 请重新登录");
}