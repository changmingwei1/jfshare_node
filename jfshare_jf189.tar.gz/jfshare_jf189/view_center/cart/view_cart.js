exports.show_cart = function(req, res, next) {
    res.render("cart/show_cart", res.resData);
}

